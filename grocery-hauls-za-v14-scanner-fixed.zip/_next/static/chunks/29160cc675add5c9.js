(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,75379,e=>{"use strict";function t(e){return null==e||Number.isNaN(e)?"R0.00":"R"+e.toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2})}function r(e,t){return t?Math.max(0,Math.round((1-e/t)*100)):0}function o(e){return e?("string"==typeof e?new Date(e):e).toLocaleDateString("en-ZA",{day:"numeric",month:"short",year:"numeric"}):""}function i(e){return Math.ceil((("string"==typeof e?new Date(e):e).getTime()-Date.now())/864e5)}function a(e){let t=i(e);return t<0?"Expired":0===t?"Ends today":1===t?"Ends tomorrow":t<=3?`Ends in ${t} days`:`Ends ${o(e)}`}function n(e){let t=i(e);return t>=0&&t<=3}function s(e){let t="string"==typeof e?new Date(e):e,r=Math.floor((Date.now()-t.getTime())/1e3);if(r<60)return"just now";let i=Math.floor(r/60);if(i<60)return`${i} min ago`;let a=Math.floor(i/60);if(a<24)return`${a}h ago`;let n=Math.floor(a/24);return n<30?`${n}d ago`:o(t)}function l(e){return e.split(" ").map(e=>e[0]).filter(Boolean).slice(0,2).join("").toUpperCase()}function d(e){let t=e.replace(/[\s\-()]/g,""),r=t.replace(/^\+27/,"0");return(!t.startsWith("+")||!!t.startsWith("+27"))&&/^0[6-8]\d{8}$/.test(r)}function c(e){let t=e.replace(/[\s\-()]/g,"").replace(/^\+27/,"0");return/^0[6-8]\d{8}$/.test(t)?"+27"+t.slice(1):null}e.s(["DISCLAIMER_MANUAL",0,"This price is user-entered or web-sourced and is not verified. Actual in-store pricing may differ.","DISCLAIMER_PRICES",0,"Prices and promotions are estimates and may change in-store. Always confirm the shelf price in-store.","NOT_ON_PROMO",0,"Not on promotion.","TAG_LABELS",0,{"black-friday":"Black Friday",festive:"Festive Season","back-to-school":"Back to School",bulk:"Bulk Buy",campaign:"Store Campaign",new:"New Products"},"TRAVEL_WARNING_THRESHOLD",0,30,"WHATSAPP_BANNER",0,"Add your WhatsApp number to receive alerts when items on your wish list go on special.","discountPct",()=>r,"endDateLabel",()=>a,"formatShortDate",()=>o,"formatZAR",()=>t,"initialsOf",()=>l,"isEndingSoon",()=>n,"isValidSAMobile",()=>d,"normalizeSAMobile",()=>c,"timeAgo",()=>s])},84658,9165,4662,e=>{"use strict";e.i(47167);var t=e.i(75379);let r=null;async function o(){if(r)return r;let[e,t,o]=await Promise.all([fetch("/data/stores.json").then(e=>e.json()),fetch("/data/categories.json").then(e=>e.json()),fetch("/data/products.json").then(e=>e.json())]);return r={stores:e.stores||[],categories:t.categories||[],products:o.products||[]}}async function i(e){let t=await e.mergedPromos(),r=new Date().toISOString().slice(0,10),o=new Map;for(let e of t){if(!e.productId)continue;let t=(e.endDate||"").slice(0,10);if(t&&t<r)continue;let i=(e.startDate||"").slice(0,10);if(i&&i>r)continue;let a=o.get(e.productId);(!a||e.promoPrice<a.promoPrice)&&o.set(e.productId,e)}return o}let a="gh_lists_v1",n="gh_wishlist_v1";function s(e,t){try{let r=window.localStorage.getItem(e);if(!r)return t;return JSON.parse(r)}catch{return t}}function l(e,t){try{window.localStorage.setItem(e,JSON.stringify(t))}catch{}}let d=()=>s(a,[]),c=()=>s(n,[]),u=()=>`local_${Date.now().toString(36)}_${Math.random().toString(36).slice(2,8)}`,p=()=>new Date().toISOString(),m=e=>{e.updatedAt=p()};function f(e){return(e||"").toLowerCase()}async function h(e,t){let{products:a}=await o(),n=await i(t),s=(e.get("q")||"").trim(),l=e.get("categoryId")||"",d=(e.get("barcode")||"").trim(),c=a;if(s){let e=f(s);c=c.filter(t=>f(t.name).includes(e)||f(t.brand||"").includes(e))}l&&(c=c.filter(e=>e.categoryId===l)),d&&(c=c.filter(e=>e.barcode===d));let u=c.slice(0,40).map(e=>{let t=Object.entries(e.storePrices),o=null;for(let[e,r]of t)(!o||r<o.price)&&(o={price:r,storeId:e});let i=n.get(e.id)??null;return{id:e.id,name:e.name,unit:e.unit,brand:e.brand,category:e.category,inPromo:!!i,promo:i?{promoPrice:i.promoPrice,normalPrice:i.normalPrice,endDate:i.endDate,storeId:i.storeId,storeName:i.storeName,storeColor:i.storeColor}:null,price:o?.price??null,lowestStoreName:o?r?.stores.find(e=>e.id===o.storeId)?.name??null:null,lowestStoreId:o?.storeId??null}});return u.sort((e,t)=>e.inPromo!==t.inPromo?e.inPromo?-1:1:e.name.localeCompare(t.name)),{results:u}}async function g(e){let t=(e.get("q")||"").trim();if(t.length<3)return{suggestions:[],source:"none"};let{products:r,stores:i}=await o(),a=f(t),n=new Map(i.map(e=>[e.id,e])),s=r.filter(e=>f(e.name).includes(a)||f(e.brand||"").includes(a)).slice(0,5).map(e=>{let t=Object.entries(e.storePrices),r=null;for(let[e,o]of t)(!r||o<r.price)&&(r={price:o,storeId:e});let o=r?n.get(r.storeId)?.name??"":"";return{title:`${e.name}${e.unit?` — ${e.unit}`:""}`,snippet:r?`In the catalogue: from R${r.price.toFixed(2)} at ${o}. Enter the shelf price you saw if it differs.`:"In the catalogue, but no stored shelf price yet — enter the price from the tag.",url:"",price:r?.price??null}});return{suggestions:s,source:s.length?"catalogue":"none"}}async function w(e,t){let{stores:a}=await o(),n=await i(e),s=new Map(a.map(e=>[e.id,e])),l=new Map((r?.products??[]).map(e=>[e.id,e]));return t.map(e=>{let t=e.productId?l.get(e.productId):void 0,r=e.productId?n.get(e.productId)??null:null,o=null;if(t)for(let[e,r]of Object.entries(t.storePrices))(!o||r<o.price)&&(o={price:r,storeId:e});return{id:e.id,productId:e.productId,name:t?.name??e.manualName??"Item",unit:t?.unit??null,categoryIcon:t?.category.icon??"🛒",categoryName:t?.category.name??null,quantity:e.quantity,source:e.source,manualStoreId:e.manualStoreId,manualStoreName:e.manualStoreId?s.get(e.manualStoreId)?.name??null:null,manualPrice:e.manualPrice,lowestPrice:o?.price??null,lowestStoreName:o?s.get(o.storeId)?.name??null:null,lowestStoreId:o?.storeId??null,promo:r?{promoPrice:r.promoPrice,normalPrice:r.normalPrice,storeName:r.storeName,storeColor:r.storeColor,storeId:r.storeId,endDate:r.endDate}:null,notOnPromo:!!e.productId&&!r}})}function y(e){return{id:e.id,name:e.name,status:e.status,shoppingMethod:e.shoppingMethod??null,itemCount:e.items.length,totalQuantity:e.items.reduce((e,t)=>e+(t.quantity||1),0),createdAt:e.createdAt,updatedAt:e.updatedAt,completedAt:e.completedAt,lastTotal:e.lastTotal,lastSavings:e.lastSavings}}async function I(){return{lists:d().slice().sort((e,t)=>e.updatedAt<t.updatedAt?1:-1).map(y)}}async function P(e){let t=String(e.name||"").trim();if(!t)throw Error("Give your list a name first");let r={id:u(),name:t.slice(0,60),status:"active",shoppingMethod:"physical"===e.shoppingMethod||"online"===e.shoppingMethod?e.shoppingMethod:null,createdAt:p(),updatedAt:p(),completedAt:null,lastTotal:null,lastSavings:null,items:[],plans:[]},o=d();return o.push(r),l(a,o),{list:{id:r.id,name:r.name,shoppingMethod:r.shoppingMethod}}}async function S(e,t){let r=function(e){let t=d().find(t=>t.id===e);if(!t)throw Error("List not found");return t}(e);return{list:{id:r.id,name:r.name,status:r.status,shoppingMethod:r.shoppingMethod??null,createdAt:r.createdAt,updatedAt:r.updatedAt,completedAt:r.completedAt,lastTotal:r.lastTotal,lastSavings:r.lastSavings},items:await w(t,r.items),plans:r.plans}}async function b(e,t){let r=d(),o=r.find(t=>t.id===e);if(!o)throw Error("List not found");return"string"==typeof t.name&&t.name.trim()&&(o.name=t.name.trim().slice(0,60)),("physical"===t.shoppingMethod||"online"===t.shoppingMethod)&&(o.shoppingMethod=t.shoppingMethod),"completed"===t.status&&(o.status="completed",o.completedAt=p()),"active"===t.status&&(o.status="active",o.completedAt=null),"number"==typeof t.lastTotal&&(o.lastTotal=t.lastTotal),"number"==typeof t.lastSavings&&(o.lastSavings=t.lastSavings),m(o),l(a,r),{list:{id:o.id,name:o.name,status:o.status}}}async function v(e){let t=d();if(!t.find(t=>t.id===e))throw Error("List not found");return l(a,t.filter(t=>t.id!==e)),{ok:!0}}async function A(e,t){let o,i=d(),n=i.find(t=>t.id===e);if(!n)throw Error("List not found");let s=Math.max(1,Math.min(99,parseInt(String(t.quantity??"1"),10)||1)),c=!1;if(t.productId){let e=(r?.products??[]).find(e=>e.id===t.productId);if(!e)throw Error("Product not found");let i=n.items.find(t=>t.productId===e.id);i?(i.quantity=Math.min(99,i.quantity+s),t.source&&(i.source=String(t.source)),o=i,c=!0):(o={id:u(),productId:e.id,manualName:null,manualPrice:null,manualStoreId:null,quantity:s,source:String(t.source??"catalogue"),note:null,createdAt:p()},n.items.push(o))}else{let e=String(t.name||"").trim(),r=null!=t.price?Number(t.price):null;if(!e)throw Error("Enter the product name");if(null==r||Number.isNaN(r)||r<0)throw Error("Enter the shelf price from the price tag");o={id:u(),productId:null,manualName:e.slice(0,80),manualPrice:r,manualStoreId:t.storeId||null,quantity:s,source:String(t.source??"manual"),note:null,createdAt:p()},n.items.push(o)}return m(n),l(a,i),c?{item:o,merged:!0}:{item:o}}async function N(e,t){let r=d(),o=r.find(t=>t.id===e);if(!o)throw Error("List not found");if(!t.itemId)throw Error("Missing itemId");let i=o.items.find(e=>e.id===t.itemId);if(!i)throw Error("Item not found");if(null!=t.quantity&&(i.quantity=Math.max(1,Math.min(99,parseInt(String(t.quantity),10)||1))),"string"==typeof t.note&&(i.note=t.note.slice(0,200)),null!=t.price&&"catalogue"!==i.source){let e=Number(t.price);!Number.isNaN(e)&&e>=0&&(i.manualPrice=e)}return m(o),l(a,r),{item:i}}async function D(e,t){let r=d(),o=r.find(t=>t.id===e);if(!o)throw Error("List not found");let i=t.get("itemId");if(!i)throw Error("Missing itemId");return o.items=o.items.filter(e=>e.id!==i),m(o),l(a,r),{ok:!0}}async function E(e){let t=d(),r=t.find(t=>t.id===e);if(!r)throw Error("List not found");let o={...r,id:u(),name:`${r.name} (copy)`.slice(0,60),createdAt:p(),updatedAt:p(),completedAt:null,status:"active",plans:[],items:r.items.map(e=>({...e,id:u(),createdAt:p()}))};return t.push(o),l(a,t),{list:{id:o.id,name:o.name}}}async function M(e){let{products:t,stores:r}=await o(),a=await i(e),n=new Map(t.map(e=>[e.id,e]));return r.map(e=>[e.id,e]),{items:c().slice().sort((e,t)=>e.createdAt<t.createdAt?1:-1).map(e=>{let t=n.get(e.productId),r=a.get(e.productId)??null,o=null;if(t)for(let e of Object.values(t.storePrices))(null==o||e<o)&&(o=e);return{id:e.id,productId:e.productId,name:t?.name??"Product",unit:t?.unit??null,categoryIcon:t?.category.icon??"🛒",categoryName:t?.category.name??null,targetPrice:e.targetPrice,preferredStoreIds:e.preferredStoreIds,onPromo:!!r,statusText:r?`On promotion at ${r.storeName}`:"Not on promotion yet.",bestPromo:r?{promoPrice:r.promoPrice,normalPrice:r.normalPrice,storeName:r.storeName,storeColor:r.storeColor,endDate:r.endDate,meetsTarget:null==e.targetPrice||r.promoPrice<=e.targetPrice}:null,normalFrom:o}})}}async function T(e){if(!e.productId)throw Error("Missing product");let t=(r?.products??[]).find(t=>t.id===e.productId);if(!t)throw Error("Product not found");let o=null!=e.targetPrice&&""!==e.targetPrice?Number(e.targetPrice):null;if(null!=o&&(Number.isNaN(o)||o<0))throw Error("Target price must be a positive amount");let i=Array.isArray(e.preferredStoreIds)?e.preferredStoreIds:[],a=c(),s=a.find(e=>e.productId===t.id);if(s)return s.targetPrice=o,s.preferredStoreIds=i,l(n,a),{item:s,updated:!0};let d={id:u(),productId:t.id,targetPrice:o,preferredStoreIds:i,createdAt:p()};return a.push(d),l(n,a),{item:d}}async function O(e,t){let r=c(),o=r.find(t=>t.id===e);if(!o)throw Error("Wish not found");if(void 0!==t.targetPrice){let e=null==t.targetPrice||""===t.targetPrice?null:Number(t.targetPrice);if(null!=e&&(!Number.isFinite(e)||e<0))throw Error("Target price must be a positive amount");o.targetPrice=e}return Array.isArray(t.preferredStoreIds)&&(o.preferredStoreIds=t.preferredStoreIds),l(n,r),{item:o}}async function C(e){return l(n,c().filter(t=>t.id!==e)),{ok:!0}}let x=e=>Math.round(100*e)/100;async function L(e,r,i,a){let n=d().find(e=>e.id===r);if(!n)return null;let{stores:s,products:l}=await o(),c=i.map(e=>s.find(t=>t.id===e)).filter(Boolean);if(0===c.length)return null;let u=new Map(l.map(e=>[e.id,e])),m=await e.mergedPromos(),f=p(),h=new Map;for(let e of m){if(!c.some(t=>t.id===e.storeId)||e.endDate&&e.endDate<f||e.startDate&&e.startDate>f)continue;let t=`${e.productId}:${e.storeId}`,r=u.get(e.productId)?.storePrices[e.storeId]??e.normalPrice??e.promoPrice,o=h.get(t);(!o||e.promoPrice<o.promoPrice)&&h.set(t,{price:e.promoPrice,promoPrice:e.promoPrice,normal:r})}let g=(e,t)=>{let r=`${e}:${t}`,o=h.get(r);if(o)return o;let i=u.get(e)?.storePrices[t];return null==i?null:{price:i,promoPrice:null,normal:i}},w=n.items,y=c.map(e=>{let t=0,r=0,o=0,i=0,n=0,s=0,l=[];for(let a of w){let d=a.quantity||1;if(a.productId&&u.has(a.productId)){let c=g(a.productId,e.id);if(!c){l.push(u.get(a.productId).name);continue}i+=1,t+=c.price*d,o+=c.normal*d,null!=c.promoPrice?(s+=1,r+=(c.normal-c.promoPrice)*d):n+=1}else a.productId?l.push(a.manualName||"Item"):a.manualStoreId===e.id?(i+=1,t+=(a.manualPrice??0)*d,n+=1):l.push(a.manualName||"Manual item")}return{storeId:e.id,name:e.name,color:e.color,emoji:e.emoji,available:i,missing:l.length,missingNames:l,notOnPromo:n,onPromo:s,total:x(t),fullTotal:x(o),savings:x(r),cheapest:!1,mostExpensive:!1,preferred:e.id===a}}),I=[...y.filter(e=>e.available>0)].sort((e,t)=>e.total-t.total),P=I[0]??null,S=I.length>1?I[I.length-1]:null;for(let e of y)e.cheapest=P?.storeId===e.storeId,e.mostExpensive=S?.storeId===e.storeId;let b=P&&S?x(S.total-P.total):0,v=null;if(c.length>=2&&w.length>0){let e=null;for(let t=0;t<c.length;t++)for(let r=t+1;r<c.length;r++){let o=c[t],i=c[r],a=0;for(let e of w){let t=e.quantity||1;if(e.productId&&u.has(e.productId)){let r=g(e.productId,o.id),n=g(e.productId,i.id);if(!r&&!n)continue;a+=Math.min(r?r.price*t:1/0,n?n.price*t:1/0)}else{if(e.productId)continue;(e.manualStoreId===o.id||e.manualStoreId===i.id)&&(a+=(e.manualPrice??0)*t)}}(!e||a<e.total)&&(e={a:o,b:i,total:a})}if(e){let{a:r,b:o}=e,i=[],n=[],s=0,l=0;for(let e of w){let t=e.quantity||1;if(e.productId&&u.has(e.productId)){let d,c=g(e.productId,r.id),p=g(e.productId,o.id);if(null==c&&null==p)continue;let m=c?c.price*t:1/0,f=p?p.price*t:1/0,h="a"==(d=a===r.id&&c?"a":a===o.id&&p?"b":m<=f?"a":"b")?c:p,w="a"===d?r:o,y=u.get(e.productId),I={itemId:e.id,name:y.name,quantity:t,unit:y.unit,price:x(h.price*t),storeId:w.id,storeName:w.name,storeColor:w.color};"a"===d?(i.push(I),s+=I.price):(n.push(I),l+=I.price)}else{if(e.productId)continue;let a=e.manualStoreId===r.id?r:e.manualStoreId===o.id?o:null;if(!a)continue;let d={itemId:e.id,name:e.manualName||"Manual item",quantity:t,unit:null,price:x((e.manualPrice??0)*t),storeId:a.id,storeName:a.name,storeColor:a.color};a.id===r.id?(i.push(d),s+=d.price):(n.push(d),l+=d.price)}}let d=x(s+l),c=P?.total??d,p=x(c-d);v={store1:{storeId:r.id,name:r.name,color:r.color,items:i,cost:x(s)},store2:{storeId:o.id,name:o.name,color:o.color,items:n,cost:x(l)},splitTotal:d,cheapestSingleTotal:c,saving:p,worthIt:p>0,travelWarning:p>0&&p<t.TRAVEL_WARNING_THRESHOLD}}}return{listId:n.id,listName:n.name,stores:y,cheapest:P?{storeId:P.storeId,name:P.name,total:P.total,savings:P.savings}:null,mostExpensive:S?{storeId:S.storeId,name:S.name,total:S.total}:null,overallCheaperBy:b,split:v,itemCount:w.length}}async function j(e,t){let r=d(),o=r.find(t=>t.id===e);if(!o)throw Error("List not found");let i=String(t.choice||"");if(!["cheapest","preferred","split"].includes(i))throw Error("Invalid plan choice");let n=Number(t.totalCost)||0,s=Number(t.savings)||0,c={id:u(),choice:i,storeIds:Array.isArray(t.storeIds)?t.storeIds:[],totalCost:n,savings:s,details:t.details??{},createdAt:p()};return o.plans.unshift(c),o.plans.length>5&&(o.plans=o.plans.slice(0,5)),o.lastTotal=n,o.lastSavings=s,m(o),l(a,r),{plan:{id:c.id}}}async function R(e,t,r,i){await o();let[a,n]=t.split("?"),s=new URLSearchParams(n||""),l=r??{};if("GET"===e&&"/api/products"===a)return await h(s,i);if("GET"===e&&"/api/lookup"===a)return await g(s);if("/api/lists"===a)return"GET"===e?await I():"POST"===e?await P(l):null;let d=a.match(/^\/api\/lists\/([^/]+)$/);if(d)return"GET"===e?await S(d[1],i):"PATCH"===e?await b(d[1],l):"DELETE"===e?await v(d[1]):null;if(d=a.match(/^\/api\/lists\/([^/]+)\/items$/))return"POST"===e?await A(d[1],l):"PATCH"===e?await N(d[1],l):"DELETE"===e?await D(d[1],s):null;if((d=a.match(/^\/api\/lists\/([^/]+)\/duplicate$/))&&"POST"===e)return await E(d[1]);if((d=a.match(/^\/api\/lists\/([^/]+)\/compare$/))&&"GET"===e){let e=(s.get("stores")||"").split(",").map(e=>e.trim()).filter(Boolean),t=s.get("preferred")||null;if(e.length<1)throw Error("Select at least one store to compare");if(e.length>7)throw Error("Select up to 7 stores");let r=await L(i,d[1],e,t);if(!r)throw Error("List not found");return{result:r}}if((d=a.match(/^\/api\/lists\/([^/]+)\/plan$/))&&"POST"===e)return await j(d[1],l);if("/api/wishlist"===a)return"GET"===e?await M(i):"POST"===e?await T(l):null;if(d=a.match(/^\/api\/wishlist\/([^/]+)$/)){if("PATCH"===e)return await O(d[1],l);if("DELETE"===e)return await C(d[1])}if("/api/shop/sessions"===a)return"POST"===e?await GhShop().create(l,i):null;if(d=a.match(/^\/api\/shop\/sessions\/([^/]+)$/))return"GET"===e?await GhShop().get(d[1]):"PATCH"===e?await GhShop().patch(d[1],l):null;if(d=a.match(/^\/api\/shop\/sessions\/([^/]+)\/items$/))return"POST"===e?await GhShop().addItem(d[1],l,i):"PATCH"===e?await GhShop().patchItem(d[1],l):"DELETE"===e?await GhShop().delItem(d[1],s):null;return null}/* GH v14: on-device shop sessions + barcode lookup (see scripts/gh_scanner_core.mjs) */
function ghNormaliseBarcode(raw) {
  if (raw === null || raw === undefined) {
    return { ok: false, code: '', candidates: [], error: 'No barcode was read — try again or type it below.' };
  }
  var digits = String(raw).replace(/[^0-9]/g, '');
  if (!digits) {
    return { ok: false, code: '', candidates: [], error: 'A barcode must contain digits (0-9) only.' };
  }
  if ([8, 12, 13, 14].indexOf(digits.length) === -1) {
    return {
      ok: false,
      code: digits,
      candidates: [],
      error: 'Barcodes are 8, 12, 13 or 14 digits long — this one has ' + digits.length + ' digits.'
    };
  }
  var candidates;
  if (digits.length === 12) {
    // UPC-A -> also try as EAN-13 with implied leading zero (leading zero kept as a string)
    candidates = ['0' + digits, digits];
  } else if (digits.length === 14) {
    // GTIN-14 -> also try the 13-digit form
    candidates = [digits, digits.slice(-13)];
  } else {
    // EAN-8 / EAN-13 stay as-is; leading zeroes are never lost (string, not number)
    candidates = [digits];
  }
  return { ok: true, code: candidates[0], candidates: candidates, digits: digits };
}

function ghFindProductByBarcode(products, candidates) {
  if (!products || !products.length) return null;
  for (var i = 0; i < candidates.length; i++) {
    for (var j = 0; j < products.length; j++) {
      if (products[j] && products[j].barcode === candidates[i]) return products[j];
    }
  }
  return null;
}

function ghPriceForStore(product, storeId) {
  var sp = product && product.storePrices ? product.storePrices : {};
  if (storeId && typeof sp[storeId] === 'number' && sp[storeId] >= 0) {
    return { price: sp[storeId], exact: true };
  }
  var best = null;
  for (var sid in sp) {
    var v = sp[sid];
    if (typeof v === 'number' && v >= 0 && (best === null || v < best.price)) {
      best = { price: v, storeId: sid };
    }
  }
  return best ? { price: best.price, exact: false } : null;
}

function ghBuildPromoMap(promos, todayISO) {
  var map = {};
  if (!promos || !promos.length) return map;
  for (var i = 0; i < promos.length; i++) {
    var p = promos[i];
    if (!p || !p.productId || typeof p.promoPrice !== 'number' || !Number.isFinite(p.promoPrice)) continue;
    var end = (p.endDate || '').slice(0, 10);
    if (end && end < todayISO) continue;
    var start = (p.startDate || '').slice(0, 10);
    if (start && start > todayISO) continue;
    var cur = map[p.productId];
    if (!cur || p.promoPrice < cur.promoPrice) map[p.productId] = p;
  }
  return map;
}

/**
 * Duplicate-scan guard state machine (used by the camera callback).
 * Accepts a scan only if it is a new code, or the same code after minIntervalMs.
 * state = { txt: string, at: number, busy: boolean }
 */
function ghShouldAcceptScan(state, code, now, minIntervalMs) {
  if (!state || typeof state !== 'object') return false;
  if (state.busy) return false;
  if (!code) return false;
  if (state.txt === code && now - state.at < (minIntervalMs || 2500)) return false;
  return true;
}

function ghCameraErrorMessage(err) {
  var name = err && err.name ? err.name : '';
  if (name === 'NotAllowedError' || name === 'PermissionDeniedError') {
    return 'Camera permission was denied. Allow camera access for this site in your browser settings, then tap Scan barcode again — or type the barcode below.';
  }
  if (name === 'NotFoundError' || name === 'DevicesNotFoundError') {
    return 'No camera was found on this device. Type the barcode below instead.';
  }
  if (name === 'NotReadableError' || name === 'TrackStartError') {
    return 'The camera is busy — another app or browser tab is using it. Close it and tap Scan barcode again.';
  }
  if (name === 'OverconstrainedError') {
    return 'This camera does not support the requested mode. Try switching cameras, or type the barcode below.';
  }
  if (name === 'SecurityError') {
    return 'Your browser blocked camera access. Type the barcode below instead.';
  }
  return 'Could not start the camera. Allow camera access, or type the barcode below.';
}

/**
 * Factory for the on-device shop-session store.
 * deps:
 *   read(key, fallback) / write(key, value)  — localStorage wrappers
 *   uid() / nowISO()                         — id + timestamp generators
 *   loadCatalogue() -> Promise<{products, stores, categories}>
 *   loadLists() -> array of local lists (gh_lists_v1 shape)
 */
function ghCreateShopSessionStore(deps) {
  var SESSIONS_KEY = 'gh_shop_sessions_v1';
  var USER_PRODUCTS_KEY = 'gh_scan_products_v1';

  function readSessions() {
    var v = deps.read(SESSIONS_KEY, []);
    return Array.isArray(v) ? v : [];
  }
  function readUserProducts() {
    var v = deps.read(USER_PRODUCTS_KEY, []);
    return Array.isArray(v) ? v : [];
  }

  function findSession(id) {
    var all = readSessions();
    for (var i = 0; i < all.length; i++) {
      if (all[i] && all[i].id === id) return { session: all[i], all: all };
    }
    throw new Error('This shopping session has ended. Start Shop Mode again.');
  }

  function saveSessions(all) {
    deps.write(SESSIONS_KEY, all);
  }

  function priceFor(product, storeId) {
    var r = ghPriceForStore(product, storeId);
    return r ? r.price : null;
  }

  async function promoMap(ctx) {
    var today = new Date().toISOString().slice(0, 10);
    try {
      var promos = ctx && typeof ctx.mergedPromos === 'function' ? await ctx.mergedPromos() : [];
      return ghBuildPromoMap(promos, today);
    } catch (e) {
      return {};
    }
  }

  function summarise(session, listTotal) {
    var items = session.items || [];
    var subtotal = 0;
    var savings = 0;
    var unpriced = 0;
    var bought = 0;
    for (var i = 0; i < items.length; i++) {
      var it = items[i];
      var qty = it.quantity || 1;
      if (typeof it.price === 'number' && Number.isFinite(it.price)) {
        subtotal += it.price * qty;
        if (typeof it.promoPrice === 'number' && it.promoPrice < it.price) {
          savings += Math.max(0, it.price - it.promoPrice) * qty;
        }
      } else {
        unpriced += 1;
      }
      if (it.bought) bought += 1;
    }
    var out = {
      itemsScanned: session.scans || 0,
      promoSavings: Math.round(savings * 100) / 100,
      estimatedTotal: Math.round(subtotal * 100) / 100,
      itemsInBasket: items.length,
      subtotal: Math.round(subtotal * 100) / 100,
      unpricedCount: unpriced
    };
    if (session.listId) {
      var total = typeof listTotal === 'number' ? listTotal : items.filter(function (x) { return x.source === 'list'; }).length;
      out.listTotal = total;
      out.listRemaining = Math.max(0, total - bought);
      out.itemsBought = bought;
    }
    return out;
  }

  function publicItem(it) {
    return {
      id: it.id,
      productId: it.productId ?? null,
      barcode: it.barcode ?? null,
      name: it.name,
      brand: it.brand ?? null,
      unit: it.unit ?? null,
      price: it.price ?? null,
      quantity: it.quantity || 1,
      bought: !!it.bought,
      source: it.source,
      promoPrice: it.promoPrice ?? null
    };
  }

  function toResponse(session, stores) {
    var store = null;
    for (var i = 0; i < (stores || []).length; i++) {
      if (stores[i].id === session.storeId) store = stores[i];
    }
    var listTotal = null;
    if (session.listId) {
      var lists = deps.loadLists() || [];
      for (var j = 0; j < lists.length; j++) {
        if (lists[j].id === session.listId) listTotal = (lists[j].items || []).length;
      }
    }
    var storeOut = store ? {
      id: store.id,
      name: store.name,
      color: store.color ?? null,
      logo: store.logo ?? null
    } : { id: session.storeId, name: 'Store', color: null };
    var listName = null;
    if (session.listId) {
      var lists2 = deps.loadLists() || [];
      for (var li2 = 0; li2 < lists2.length; li2++) {
        if (lists2[li2].id === session.listId) listName = lists2[li2].name ?? null;
      }
    }
    return {
      session: {
        id: session.id,
        storeId: session.storeId,
        listId: session.listId ?? null,
        listName: listName,
        status: session.status,
        createdAt: session.createdAt,
        completedAt: session.completedAt ?? null,
        store: storeOut
      },
      store: storeOut,
      items: (session.items || []).map(publicItem),
      summary: summarise(session, listTotal)
    };
  }

  function seedFromList(session, list, products, promoById) {
    var items = session.items || [];
    var lis = list && list.items ? list.items : [];
    for (var i = 0; i < lis.length; i++) {
      var li = lis[i];
      var product = null;
      if (li.productId) {
        for (var k = 0; k < products.length; k++) {
          if (products[k] && products[k].id === li.productId) product = products[k];
        }
      }
      var promo = product ? promoById[product.id] : null;
      var item;
      if (product) {
        item = {
          id: deps.uid(),
          productId: product.id,
          barcode: product.barcode ?? null,
          name: product.name,
          brand: product.brand ?? null,
          unit: product.unit ?? null,
          price: priceFor(product, session.storeId),
          quantity: li.quantity || 1,
          bought: false,
          source: 'list',
          promoPrice: promo ? promo.promoPrice : null
        };
      } else {
        item = {
          id: deps.uid(),
          productId: null,
          barcode: null,
          name: li.manualName || 'Item',
          brand: null,
          unit: null,
          price: typeof li.manualPrice === 'number' ? li.manualPrice : null,
          quantity: li.quantity || 1,
          bought: false,
          source: 'list',
          promoPrice: null
        };
      }
      items.push(item);
    }
    session.items = items;
  }

  function upsertUserProduct(record) {
    var all = readUserProducts();
    var found = null;
    for (var i = 0; i < all.length; i++) {
      if (all[i].barcode === record.barcode) found = all[i];
    }
    if (found) {
      if (record.name) found.name = record.name;
      if (record.brand) found.brand = record.brand;
      if (record.unit) found.unit = record.unit;
      if (typeof record.price === 'number') found.price = record.price;
      found.updatedAt = deps.nowISO();
    } else {
      found = {
        barcode: record.barcode,
        name: record.name || 'Unidentified product',
        brand: record.brand ?? null,
        unit: record.unit ?? null,
        price: typeof record.price === 'number' ? record.price : null,
        source: 'shopper',
        createdAt: deps.nowISO(),
        updatedAt: deps.nowISO()
      };
      all.push(found);
    }
    deps.write(USER_PRODUCTS_KEY, all);
    return found;
  }

  return {
    async create(body, ctx) {
      var cat = await deps.loadCatalogue();
      var storeId = body && body.storeId ? String(body.storeId) : '';
      var storeOk = false;
      for (var i = 0; i < (cat.stores || []).length; i++) {
        if (cat.stores[i].id === storeId) storeOk = true;
      }
      if (!storeOk) throw new Error('Choose the store you are shopping at first.');
      var session = {
        id: deps.uid(),
        storeId: storeId,
        listId: body && body.listId ? String(body.listId) : null,
        status: 'active',
        createdAt: deps.nowISO(),
        completedAt: null,
        items: [],
        scans: 0
      };
      if (session.listId) {
        var lists = deps.loadLists() || [];
        var list = null;
        for (var j = 0; j < lists.length; j++) {
          if (lists[j].id === session.listId) list = lists[j];
        }
        if (list) {
          var pm = await promoMap(ctx);
          seedFromList(session, list, cat.products || [], pm);
        }
      }
      var all = readSessions();
      all.push(session);
      saveSessions(all);
      return { session: { id: session.id, storeId: session.storeId, listId: session.listId } };
    },

    async get(id) {
      var cat = await deps.loadCatalogue();
      var found = findSession(id);
      return toResponse(found.session, cat.stores || []);
    },

    async patch(id, body) {
      var cat = await deps.loadCatalogue();
      var found = findSession(id);
      if (body && body.status === 'completed') {
        found.session.status = 'completed';
        found.session.completedAt = deps.nowISO();
      }
      if (body && body.status === 'active') {
        found.session.status = 'active';
        found.session.completedAt = null;
      }
      saveSessions(found.all);
      return toResponse(found.session, cat.stores || []);
    },

    async addItem(id, body, ctx) {
      var cat = await deps.loadCatalogue();
      var found = findSession(id);
      var session = found.session;
      var source = body && body.source ? String(body.source) : 'manual';
      var message = '';
      var onPromo = false;

      if (source === 'scan') {
        var norm = ghNormaliseBarcode(body ? body.barcode : '');
        if (!norm.ok) throw new Error(norm.error);
        var product = ghFindProductByBarcode(cat.products || [], norm.candidates);
        session.scans = (session.scans || 0) + 1;

        if (product) {
          var pm = await promoMap(ctx);
          var promo = pm[product.id] || null;
          var price = priceFor(product, session.storeId);
          var promoPrice = promo && typeof promo.promoPrice === 'number' ? promo.promoPrice : null;
          var existing = null;
          for (var i2 = 0; i2 < session.items.length; i2++) {
            if (session.items[i2].productId === product.id) existing = session.items[i2];
          }
          if (existing) {
            if (existing.source === 'list' && !existing.bought) {
              existing.bought = true;
              message = 'Ticked off your list';
            } else {
              existing.quantity = Math.min(99, (existing.quantity || 1) + 1);
              message = 'Quantity updated to ' + existing.quantity;
            }
            onPromo = existing.promoPrice !== null && existing.promoPrice !== undefined;
            saveSessions(found.all);
            return { item: publicItem(existing), onPromo: onPromo, message: message };
          }
          var item = {
            id: deps.uid(),
            productId: product.id,
            barcode: norm.code,
            name: product.name,
            brand: product.brand ?? null,
            unit: product.unit ?? null,
            price: price,
            quantity: 1,
            bought: false,
            source: 'scan',
            promoPrice: promoPrice
          };
          session.items.push(item);
          onPromo = promoPrice !== null;
          if (!onPromo) {
            message = price === null
              ? 'Price unavailable at this store — added without a price.'
              : 'Not on promotion.';
          }
          saveSessions(found.all);
          return { item: publicItem(item), onPromo: onPromo, message: message };
        }

        var userProduct = ghFindProductByBarcode(readUserProducts(), norm.candidates);
        if (userProduct) {
          var uItem = {
            id: deps.uid(),
            productId: null,
            barcode: norm.code,
            name: userProduct.name,
            brand: userProduct.brand ?? null,
            unit: userProduct.unit ?? null,
            price: typeof userProduct.price === 'number' ? userProduct.price : null,
            quantity: 1,
            bought: false,
            source: 'scan',
            promoPrice: null
          };
          var dup = null;
          for (var i3 = 0; i3 < session.items.length; i3++) {
            if (session.items[i3].barcode === norm.code) dup = session.items[i3];
          }
          if (dup) {
            dup.quantity = Math.min(99, (dup.quantity || 1) + 1);
            saveSessions(found.all);
            return { item: publicItem(dup), onPromo: false, message: 'Quantity updated to ' + dup.quantity };
          }
          session.items.push(uItem);
          saveSessions(found.all);
          return { item: publicItem(uItem), onPromo: false, message: uItem.price === null ? 'Price unavailable — added without a price.' : 'Added from your saved products.' };
        }

        saveSessions(found.all);
        throw new Error('Barcode ' + norm.code + ' is not in the product catalogue yet — add the product manually below.');
      }

      // ---- manual add (typed barcode or plain name) ----
      var name = body && body.name ? String(body.name).trim() : '';
      if (!name) throw new Error('Enter the product name first.');
      var price2 = null;
      if (body && body.price !== undefined && body.price !== null && body.price !== '') {
        price2 = Number(body.price);
        if (Number.isNaN(price2) || price2 < 0) throw new Error('Enter a valid price, e.g. 29.99 — or leave it empty.');
      }
      var brand = body && body.brand ? String(body.brand).trim() : null;
      var unit = body && body.unit ? String(body.unit).trim() : null;
      var rawBarcode = body && body.barcode ? String(body.barcode).trim() : '';

      if (rawBarcode) {
        var norm2 = ghNormaliseBarcode(rawBarcode);
        if (!norm2.ok) throw new Error(norm2.error);
        var product2 = ghFindProductByBarcode(cat.products || [], norm2.candidates);
        if (product2) {
          var pm2 = await promoMap(ctx);
          var promo2 = pm2[product2.id] || null;
          var price3 = priceFor(product2, session.storeId);
          var ex2 = null;
          for (var i4 = 0; i4 < session.items.length; i4++) {
            if (session.items[i4].productId === product2.id) ex2 = session.items[i4];
          }
          if (ex2) {
            ex2.quantity = Math.min(99, (ex2.quantity || 1) + 1);
            saveSessions(found.all);
            return { item: publicItem(ex2), onPromo: ex2.promoPrice != null, message: 'Quantity updated to ' + ex2.quantity };
          }
          var it2 = {
            id: deps.uid(),
            productId: product2.id,
            barcode: norm2.code,
            name: product2.name,
            brand: product2.brand ?? null,
            unit: product2.unit ?? null,
            price: price3,
            quantity: 1,
            bought: false,
            source: 'manual',
            promoPrice: promo2 ? promo2.promoPrice : null
          };
          session.items.push(it2);
          saveSessions(found.all);
          return { item: publicItem(it2), onPromo: it2.promoPrice != null, message: 'Matched in the catalogue.' };
        }
        upsertUserProduct({ barcode: norm2.code, name: name, brand: brand, unit: unit, price: price2 });
      }

      var mItem = {
        id: deps.uid(),
        productId: null,
        barcode: rawBarcode ? ghNormaliseBarcode(rawBarcode).code : null,
        name: name.slice(0, 80),
        brand: brand,
        unit: unit,
        price: price2,
        quantity: 1,
        bought: false,
        source: 'manual',
        promoPrice: null
      };
      session.items.push(mItem);
      saveSessions(found.all);
      return { item: publicItem(mItem), onPromo: false, message: mItem.price === null ? 'Added without a price.' : 'Added to basket.' };
    },

    async patchItem(id, body) {
      var cat = await deps.loadCatalogue();
      var found = findSession(id);
      var item = null;
      if (!body || !body.itemId) throw new Error('Missing itemId');
      for (var i = 0; i < found.session.items.length; i++) {
        if (found.session.items[i].id === body.itemId) item = found.session.items[i];
      }
      if (!item) throw new Error('Item not found');
      if (typeof body.bought === 'boolean') item.bought = body.bought;
      if (body.quantity !== undefined && body.quantity !== null) {
        var q = parseInt(String(body.quantity), 10);
        if (Number.isNaN(q)) throw new Error('Quantity must be a number');
        item.quantity = Math.max(1, Math.min(99, q));
      }
      saveSessions(found.all);
      return { item: publicItem(item), session: toResponse(found.session, cat.stores || []) };
    },

    async delItem(id, params) {
      var cat = await deps.loadCatalogue();
      var found = findSession(id);
      var itemId = params && typeof params.get === 'function' ? params.get('itemId') : (params && params.itemId);
      if (!itemId) throw new Error('Missing itemId');
      found.session.items = found.session.items.filter(function (x) { return x.id !== itemId; });
      saveSessions(found.all);
      return toResponse(found.session, cat.stores || []);
    },

    // exposed for tests + unknown-product saves from manual entry
    upsertUserProduct: upsertUserProduct,
    userProducts: readUserProducts,
    summarise: summarise
  };
}
var GhShopInst=null;function GhShop(){if(!GhShopInst)GhShopInst=ghCreateShopSessionStore({read:function(k,f){return s(k,f)},write:function(k,v){l(k,v)},uid:u,nowISO:p,loadCatalogue:o,loadLists:function(){return d()}});return GhShopInst}
let $={"/api/notifications":{notifications:[],unread:0},"/api/auth/session":{user:null}},k={"/api/stores":"/data/stores.json","/api/categories":"/data/categories.json","/api/whats-new":"/data/whats-new.json","/api/locations":"/data/locations.json","/api/online-retailers":"/data/online-retailers.json"},_=null,B=null;async function q(){try{let e=await fetch("/data/stores.json"),t=await e.json();return new Map((t.stores||[]).map(e=>[e.id,e.color]))}catch{return new Map}}async function U(){try{let[{getFirebaseDb:t},r]=await Promise.all([e.A(95251),e.A(27510)]),o=await r.getDocs(r.collection(t(),"publishedPromos")),i=new Date().toISOString().slice(0,10),a=await q(),n=[];return o.forEach(e=>{let t=e.data();if(!t?.productName||"paused"===t.status||"number"!=typeof t.promoPrice||!Number.isFinite(t.promoPrice)||t.endDate&&t.endDate<i)return;let r="number"==typeof t.normalPrice&&Number.isFinite(t.normalPrice)&&t.normalPrice>0?t.normalPrice:null,o=t.discount??(r?Math.round((r-t.promoPrice)/r*100):0);n.push({id:"live-"+e.id,productId:"live-"+e.id,name:t.productName,unit:t.unit||null,category:{id:"live-cat",name:t.category||"Imported specials",icon:"🏷️"},storeId:t.storeId||"",storeName:t.storeName||"",storeColor:a.get(t.storeId)||"#1d4ed8",promoPrice:t.promoPrice,normalPrice:r,discount:o,saved:r?Math.max(0,Math.round((r-t.promoPrice)*100)/100):0,startDate:t.startDate?new Date(t.startDate+"T00:00:00Z").toISOString():new Date().toISOString(),endDate:t.endDate?new Date(t.endDate+"T23:59:00Z").toISOString():new Date(Date.now()+2592e6).toISOString(),createdAt:t.createdAt||new Date().toISOString()})}),n}catch{return[]}}let z=e=>e.toLowerCase().replace(/[^a-z0-9]+/g,"");async function W(){if(!_){let e=await fetch("/data/promos.json");_=(await e.json()).promos;let t=new Date;_=_.filter(e=>new Date(e.startDate)<=t&&new Date(e.endDate)>=t)}if(null===B&&(B=await U()),!B.length)return _;let e=new Set(B.map(e=>`${z(e.name)}@${z(e.storeName)}`)),t=_.filter(t=>!e.has(`${z(t.name)}@${z(t.storeName)}`));return[...B,...t]}async function G(){try{let[{getFirebaseDb:t},r]=await Promise.all([e.A(95251),e.A(27510)]),o=await r.getDocs(r.query(r.collection(t(),"whatsNew"),r.orderBy("createdAt","desc"),r.limit(20))),i=await q(),a=[];return o.forEach(e=>{let t=e.data();t?.title&&!1!==t.active&&a.push({id:"live-"+e.id,title:t.title,description:t.description||"",imageUrl:null,tag:t.tag||"new",datePosted:t.datePosted||new Date().toISOString(),storeName:t.storeName||null,storeColor:t.storeId&&i.get(t.storeId)||null,promos:[]})}),a}catch{return[]}}async function F(e){let[t,r]=e.split("?"),o=new URLSearchParams(r||"");if(void 0!==$[t])return $[t];if("/api/promos"===t){let e=await W(),t=o.get("store")||"",r=o.get("category")||"",i=o.get("sort")||"discount",a=e;switch(t&&(a=a.filter(e=>e.storeId===t)),r&&(a=a.filter(e=>e.category.id===r)),a=[...a],i){case"price":a.sort((e,t)=>e.promoPrice-t.promoPrice);break;case"ending":a.sort((e,t)=>new Date(e.endDate).getTime()-new Date(t.endDate).getTime());break;case"new":a.sort((e,t)=>new Date(t.createdAt).getTime()-new Date(e.createdAt).getTime());break;default:a.sort((e,t)=>t.discount-e.discount||e.promoPrice-t.promoPrice)}return{promos:a}}if(k[t]){if("/api/whats-new"===t)try{let e=await fetch(k[t]).then(e=>e.json());return{posts:[...await G(),...e.posts||[]]}}catch{}let e=await fetch(k[t]);if(!e.ok)throw Error(`Failed to load ${k[t]} (${e.status})`);return await e.json()}throw Error(`Not available in this offline build: ${t}`)}async function H(e,t={}){let{json:r,...o}=t,i=(o.method||"GET").toUpperCase();{let t=await R(i,e,r,{mergedPromos:()=>W()});if(null!==t)return t;if("GET"!==i)throw Error("This action isn't available in this offline build yet. Everything else — lists, wish list and specials — works right here on your phone.");return F(e)}}let V=e=>H(e),Z=(e,t)=>H(e,{method:"POST",json:t}),K=(e,t)=>H(e,{method:"PATCH",json:t}),J=e=>H(e,{method:"DELETE"});e.s(["STATIC_MODE",0,!0,"apiDelete",0,J,"apiGet",0,V,"apiPatch",0,K,"apiPost",0,Z,"ghNormaliseBarcode",0,ghNormaliseBarcode,"ghShouldAcceptScan",0,ghShouldAcceptScan,"ghCameraErrorMessage",0,ghCameraErrorMessage],9165);let Q=["tshepo63mping@gmail.com"];function Y(e){return!!e&&Q.includes(e.trim().toLowerCase())}e.s(["ADMIN_EMAILS",0,Q,"isAllowedAdminEmail",()=>Y],4662);let X="firestore",ee=null;async function et(){if(ee)return ee;let[{getFirebaseDb:t,getFirebaseAuth:r},o]=await Promise.all([e.A(95251),e.A(27510)]);return ee={db:t(),auth:r(),fs:o}}async function er(){!1;let{auth:e}=await et(),t=e.currentUser;return t&&Y(t.email)?{email:t.email}:null}async function eo(){!1;let{auth:e,fs:t}=await et();await t.signOut(e).catch(()=>{})}async function ei(){!1;let{db:e,fs:t}=await et(),r=new Date,o=new Date(r.getTime()-6048e5).toISOString(),i=new Date(r.getTime()-2592e6).toISOString(),[a,n,s,l,d]=await Promise.all([t.getDocs(t.collection(e,"userProfiles")),t.getDocs(t.collection(e,"imports")),t.getDocs(t.collection(e,"publishedPromos")),fetch("/data/stores.json").then(e=>e.json()).catch(()=>({stores:[]})),fetch("/data/promos.json").then(e=>e.json()).catch(()=>({promos:[]}))]),c=a.docs.map(e=>e.data()),u=s.docs.map(e=>e.data()),p=u.filter(e=>"paused"!==e.status&&(!e.endDate||e.endDate>=r.toISOString().slice(0,10)));n.docs.map(e=>e.data()).filter(e=>e.createdAt&&e.createdAt>=o).length;let m=new Set((d.promos||[]).map(e=>e.name.toLowerCase())).size+u.length;return{stats:{totalUsers:c.length,newUsersWeek:c.filter(e=>e.createdAt&&e.createdAt>=o).length,activeUsers:c.filter(e=>e.lastLoginAt&&e.lastLoginAt>=i).length,totalLists:0,completedLists:0,totalProducts:m,totalPromotions:d.promos?.length??0+p.length,totalWishItems:0,whatsappUsers:0,shopSessions:0,estimatedSavings:0},topSearches:[],topPromoProducts:[],topStores:(l.stores||[]).slice(0,6).map(e=>({name:e.name,count:0}))}}async function ea(e){!1;let{db:t,fs:r}=await et();return(await r.getDocs(r.query(r.collection(t,"userProfiles"),r.orderBy("lastLoginAt","desc")))).docs.map(e=>{let t=e.data();return{id:e.id,name:t.name||t.email?.split("@")[0]||"Shopper",email:t.email||"",whatsappNumber:t.whatsappNumber||null,whatsappOptIn:!1,role:Y(t.email)?"admin":"user",isDemo:!1,createdAt:t.createdAt||t.lastLoginAt||new Date().toISOString(),lastLoginAt:t.lastLoginAt||"",listCount:0,wishCount:0,sessionCount:0,planCount:0}}).filter(t=>!e||t.email.toLowerCase().includes(e.toLowerCase())||t.name.toLowerCase().includes(e.toLowerCase()))}async function en(e){try{let{db:t,fs:r}=await et(),o={email:e.email,name:e.name||e.email.split("@")[0],lastLoginAt:new Date().toISOString(),createdAt:r.serverTimestamp()};void 0!==e.province&&(o.province=e.province),void 0!==e.city&&(o.city=e.city),void 0!==e.shoppingMethod&&(o.shoppingMethod=e.shoppingMethod),void 0!==e.whatsappNumber&&(o.whatsappNumber=e.whatsappNumber),void 0!==e.whatsappOptIn&&(o.whatsappOptIn=e.whatsappOptIn),await r.setDoc(r.doc(t,"userProfiles",e.uid),o,{merge:!0})}catch{}}async function es(e){try{let{db:t,fs:r}=await et(),o=await r.getDoc(r.doc(t,"userProfiles",e));if(!o.exists())return{province:null,city:null,shoppingMethod:null,whatsappNumber:null,whatsappOptIn:!1};let i=o.data();return{province:"string"==typeof i.province?i.province:null,city:"string"==typeof i.city?i.city:null,shoppingMethod:"physical"===i.shoppingMethod||"online"===i.shoppingMethod?i.shoppingMethod:null,whatsappNumber:"string"==typeof i.whatsappNumber?i.whatsappNumber:null,whatsappOptIn:"boolean"==typeof i.whatsappOptIn&&i.whatsappOptIn}}catch{return{province:null,city:null,shoppingMethod:null,whatsappNumber:null,whatsappOptIn:!1}}}async function el(e){!1;let{db:t,fs:r,auth:o}=await et(),i=o.currentUser?.email||"admin",a=new Date().toISOString(),n=r.doc(r.collection(t,"imports")),s=r.writeBatch(t);s.set(n,{storeId:e.storeId,storeName:e.storeName,periodStart:e.periodStart,periodEnd:e.periodEnd,fileName:e.fileName,fileType:e.fileType,fileSize:e.fileSize,source:e.source,status:"published",promoRows:e.promoRows,priceRows:e.priceRows,skipped:e.skipped,errorCount:e.errors.length,errors:e.errors.slice(0,100),createdBy:i,createdAt:a,publishedAt:a});let l=0;for(let o of e.promos){let d=r.doc(r.collection(t,"publishedPromos")),c=null!=o.normalPrice&&o.normalPrice>0?Math.round((o.normalPrice-o.promoPrice)/o.normalPrice*100):0;s.set(d,{productName:o.productName,category:o.category||"",unit:o.unit||"",barcode:o.barcode||"",promoPrice:o.promoPrice,...null!=o.normalPrice?{normalPrice:o.normalPrice}:{},startDate:o.startDate,endDate:o.endDate,storeId:e.storeId,storeName:e.storeName,discount:c,status:"published",verified:!0,source:"import",importId:n.id,createdBy:i,createdAt:a}),++l%400==0&&await s.commit()}return await s.commit(),n.id}async function ed(e){!1;let{db:t,fs:r,auth:o}=await et(),i=r.doc(r.collection(t,"imports"));return await r.setDoc(i,{storeId:e.storeId,storeName:e.storeName,periodStart:e.periodStart,periodEnd:e.periodEnd,fileName:e.fileName,fileType:e.fileType,fileSize:e.fileSize,source:e.source,status:"discarded",promoRows:e.promoRows,priceRows:e.priceRows,skipped:e.skipped,errorCount:e.errors.length,errors:e.errors.slice(0,100),createdBy:o.currentUser?.email||"admin",createdAt:new Date().toISOString(),publishedAt:null}),i.id}async function ec(){!1;let{db:e,fs:t}=await et();return(await t.getDocs(t.query(t.collection(e,"imports"),t.orderBy("createdAt","desc"),t.limit(100)))).docs.map(e=>{let t=e.data();return{id:e.id,storeName:t.storeName||"",periodStart:t.periodStart||"",periodEnd:t.periodEnd||"",fileName:t.fileName||"",fileType:t.fileType||"",fileSize:t.fileSize||0,status:t.status||"",source:t.source||"file",promoRows:t.promoRows||0,priceRows:t.priceRows||0,skipped:t.skipped||0,errorCount:t.errorCount||0,errors:t.errors||[],createdBy:t.createdBy||"",createdAt:t.createdAt||"",publishedAt:t.publishedAt||null}})}async function eu(){let{pubKey:t}=await e.A(2398),r=new Set;!1;let{db:o,fs:i}=await et();for(let e of(await i.getDocs(i.collection(o,"publishedPromos"))).docs){let o=e.data();o.productName&&o.storeName&&r.add(t(o.productName,o.storeName))}return r}async function ep(){!1;let{db:e,fs:t}=await et();return(await t.getDocs(t.query(t.collection(e,"publishedPromos"),t.orderBy("createdAt","desc"),t.limit(500)))).docs.map(e=>{let t=e.data();return{id:e.id,productName:t.productName||"",productId:"live",category:t.category||"",storeName:t.storeName||"",storeId:t.storeId||"",unit:t.unit||"",promoPrice:t.promoPrice??0,normalPrice:t.normalPrice??0,startDate:t.startDate||"",endDate:t.endDate||"",status:t.status||"published",source:t.source||"admin",verified:!0,createdAt:t.createdAt||""}})}async function em(e){!1;let{db:t,fs:r,auth:o}=await et();await r.addDoc(r.collection(t,"publishedPromos"),{...e,discount:e.normalPrice>0?Math.round((e.normalPrice-e.promoPrice)/e.normalPrice*100):0,status:"published",verified:!0,source:"admin",createdBy:o.currentUser?.email||"admin",createdAt:new Date().toISOString()})}async function ef(e,t){!1;let{db:r,fs:o}=await et();await o.updateDoc(o.doc(r,"publishedPromos",e),{status:t})}async function eh(e){!1;let{db:t,fs:r}=await et();await r.deleteDoc(r.doc(t,"publishedPromos",e))}async function eg(){!1;let{db:e,fs:t}=await et();return(await t.getDocs(t.query(t.collection(e,"whatsNew"),t.orderBy("createdAt","desc"),t.limit(100)))).docs.map(e=>{let t=e.data();return{id:e.id,title:t.title||"",description:t.description||"",tag:t.tag||"new",storeName:t.storeName??null,active:t.active??!0,datePosted:t.datePosted||t.createdAt||"",promoCount:0,promoNames:[]}})}async function ew(e){!1;let{db:t,fs:r,auth:o}=await et();await r.addDoc(r.collection(t,"whatsNew"),{...e,active:!0,datePosted:new Date().toISOString(),createdBy:o.currentUser?.email||"admin",createdAt:new Date().toISOString()})}async function ey(e,t){!1;let{db:r,fs:o}=await et();await o.updateDoc(o.doc(r,"whatsNew",e),{active:t})}async function eI(e){!1;let{db:t,fs:r}=await et();await r.deleteDoc(r.doc(t,"whatsNew",e))}async function eP(){return(await fetch("/data/stores.json").then(e=>e.json())).stores||[]}async function eS(){!1;let[e,t]=await Promise.all([fetch("/data/promos.json").then(e=>e.json()).catch(()=>({promos:[]})),ep().catch(()=>[])]),r=new Map;for(let t of e.promos||[])r.set(t.name.toLowerCase(),t.name);for(let e of t)r.set(e.productName.toLowerCase(),e.productName);return[...r.entries()].map(([e,t],r)=>({id:e,name:t}))}async function eb(){return Q.map((e,t)=>({id:`allowlist-${t}`,email:e,addedBy:"allowlist (src/lib/admin-config.ts + firestore.rules)",primary:!0}))}async function ev(){return(await ec()).map(e=>({id:e.id,filename:e.fileName,fileType:e.fileType,fileSize:e.fileSize,uploadedBy:e.createdBy,storeName:e.storeName,status:e.status,createdAt:e.createdAt,url:null}))}e.s(["ADMIN_BACKEND",0,X,"adminLogout",()=>eo,"adminSession",()=>er,"createPromotion",()=>em,"createWhatsNew",()=>ew,"deletePromotion",()=>eh,"deleteWhatsNew",()=>eI,"discardImport",()=>ed,"getPublishedKeys",()=>eu,"getStats",()=>ei,"listAdmins",()=>eb,"listFiles",()=>ev,"listImports",()=>ec,"listProductNames",()=>eS,"listPromotions",()=>ep,"listStores",()=>eP,"listUsers",()=>ea,"listWhatsNew",()=>eg,"loadMyProfile",()=>es,"publishImport",()=>el,"setPromoStatus",()=>ef,"setWhatsNewActive",()=>ey,"upsertMyProfile",()=>en],84658)},85149,e=>{"use strict";e.s(["ADMIN_EMAIL_PRIMARY",0,"tshepo63mping@gmail.com","APP_SHARE_URL",0,"https://grocery-hauls-za.pages.dev"])},19455,91918,93479,e=>{"use strict";let t,r,o;var i=e.i(43476),a=e.i(71645),n=e.i(20783),s=Symbol.for("react.lazy"),l=a[" use ".trim().toString()];function d(e){var t;return null!=e&&"object"==typeof e&&"$$typeof"in e&&e.$$typeof===s&&"_payload"in e&&"object"==typeof(t=e._payload)&&null!==t&&"then"in t}var c=((o=a.forwardRef((e,t)=>{let{children:r,...o}=e;if(d(r)&&"function"==typeof l&&(r=l(r._payload)),a.isValidElement(r)){var i;let e,s,l=(i=r,(s=(e=Object.getOwnPropertyDescriptor(i.props,"ref")?.get)&&"isReactWarning"in e&&e.isReactWarning)?i.ref:(s=(e=Object.getOwnPropertyDescriptor(i,"ref")?.get)&&"isReactWarning"in e&&e.isReactWarning)?i.props.ref:i.props.ref||i.ref),d=function(e,t){let r={...t};for(let o in t){let i=e[o],a=t[o];/^on[A-Z]/.test(o)?i&&a?r[o]=(...e)=>{let t=a(...e);return i(...e),t}:i&&(r[o]=i):"style"===o?r[o]={...i,...a}:"className"===o&&(r[o]=[i,a].filter(Boolean).join(" "))}return{...e,...r}}(o,r.props);return r.type!==a.Fragment&&(d.ref=t?(0,n.composeRefs)(t,l):l),a.cloneElement(r,d)}return a.Children.count(r)>1?a.Children.only(null):null})).displayName="Slot.SlotClone",t=o,(r=a.forwardRef((e,r)=>{let{children:o,...n}=e;d(o)&&"function"==typeof l&&(o=l(o._payload));let s=a.Children.toArray(o),c=s.find(p);if(c){let e=c.props.children,o=s.map(t=>t!==c?t:a.Children.count(e)>1?a.Children.only(null):a.isValidElement(e)?e.props.children:null);return(0,i.jsx)(t,{...n,ref:r,children:a.isValidElement(e)?a.cloneElement(e,void 0,o):null})}return(0,i.jsx)(t,{...n,ref:r,children:o})})).displayName="Slot.Slot",r),u=Symbol("radix.slottable");function p(e){return a.isValidElement(e)&&"function"==typeof e.type&&"__radixId"in e.type&&e.type.__radixId===u}e.s(["Slot",()=>c],91918);var m=e.i(25913),f=e.i(75157);let h=(0,m.cva)("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive",{variants:{variant:{default:"bg-primary text-primary-foreground shadow-xs hover:bg-primary/90",destructive:"bg-destructive text-white shadow-xs hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60",outline:"border bg-background shadow-xs hover:bg-accent hover:text-accent-foreground dark:bg-input/30 dark:border-input dark:hover:bg-input/50",secondary:"bg-secondary text-secondary-foreground shadow-xs hover:bg-secondary/80",ghost:"hover:bg-accent hover:text-accent-foreground dark:hover:bg-accent/50",link:"text-primary underline-offset-4 hover:underline"},size:{default:"h-9 px-4 py-2 has-[>svg]:px-3",sm:"h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5",lg:"h-10 rounded-md px-6 has-[>svg]:px-4",icon:"size-9"}},defaultVariants:{variant:"default",size:"default"}});function g({className:e,variant:t,size:r,asChild:o=!1,...a}){return(0,i.jsx)(o?c:"button",{"data-slot":"button",className:(0,f.cn)(h({variant:t,size:r,className:e})),...a})}function w({className:e,type:t,...r}){return(0,i.jsx)("input",{type:t,"data-slot":"input",className:(0,f.cn)("file:text-foreground placeholder:text-muted-foreground selection:bg-primary selection:text-primary-foreground dark:bg-input/30 border-input flex h-9 w-full min-w-0 rounded-md border bg-transparent px-3 py-1 text-base shadow-xs transition-[color,box-shadow] outline-none file:inline-flex file:h-7 file:border-0 file:bg-transparent file:text-sm file:font-medium disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50 md:text-sm","focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px]","aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive",e),...r})}e.s(["Button",()=>g],19455),e.s(["Input",()=>w],93479)}]);